$('#addclass').click(function() {
    $('#box').addClass('img')
  });