$('#addclass').click(function() {
    $('#box').addClass('img')
  });

$('#removeclasss').click(function(){
    $('#box').removeclass('img')
});